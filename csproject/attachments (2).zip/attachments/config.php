<?php
  $servername="localhost";
$username="root";
$password="";
$dbname="userinfo";
$conn=new mysqli($servername,$username,$password);
?>